import React from "react";
import "./Footer.css";

export default function Footer() {
  return (
    <div className="footer-div">
      <p className="footer-text">Made with ❤️ by Shanu Mishra</p>
    </div>
  );
}
